export interface DashboardData {
    departments: string[];
  
    low: number[];
    medium: number[];
    high: number[];
  
    pending: number[];
    policy: number[];
    support: number[];
  
    kraScore: number[];
    memos: number[];
  
    kraDonut: number[];
  
    table: {
      department: string;
      empCount: number;
      avgKra: number;
    }[];
  }