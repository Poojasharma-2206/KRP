import { Component, OnInit, inject } from '@angular/core';
import { NgFor } from '@angular/common';
import Chart from 'chart.js/auto';
import { KpiCardComponent } from '../shared/components/kpi-card/kpi-card';
import { Router } from '@angular/router';
import { DataService } from '../core/services/data';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [NgFor, KpiCardComponent],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss'],
})
export class DashboardComponent implements OnInit {
  [x: string]: any;

  private dataService = inject(DataService);
  private router = inject(Router);

  tableRows: any[] = [];

  ngOnInit() {
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.dataService.getDashboard().subscribe(res => {
      console.log('DATA:', res);
  
      this.tableRows = res.table;
  
      setTimeout(() => {
        this.loadCharts(res);
      }, 0);
    });
  }

  goToEmployees() {
    this.router.navigate(['/employees']);
  }

  loadCharts(data: any) {

    const depts = data.departments;
    const gridColor = 'rgba(0,0,0,0.06)';
    const tickColor = '#64748b';

    // 🧨 destroy old charts (important)
    Chart.getChart('stackedBar')?.destroy();
    Chart.getChart('groupedBar')?.destroy();
    Chart.getChart('kraDonut')?.destroy();
    Chart.getChart('kraGauge')?.destroy();
    Chart.getChart('kraLineChart')?.destroy();
    Chart.getChart('policyDonut')?.destroy();

    // ── STACKED BAR ──
    new Chart('stackedBar', {
      type: 'bar',
      data: {
        labels: depts,
        datasets: [
          { label: 'Low', data: data.low, backgroundColor: '#22c55e', stack: 'a' },
          { label: 'Medium', data: data.medium, backgroundColor: '#f59e0b', stack: 'a' },
          { label: 'High', data: data.high, backgroundColor: '#ef4444', stack: 'a' },
        ],
      }
    });

    // ── GROUPED BAR ──
    new Chart('groupedBar', {
      type: 'bar',
      data: {
        labels: depts,
        datasets: [
          { label: 'Pending', data: data.pending, backgroundColor: '#ef4444' },
          { label: 'Policy focus', data: data.policy, backgroundColor: '#4f8ef7' },
          { label: 'Support load', data: data.support, backgroundColor: '#f59e0b' },
        ],
      }
    });

    // ── DONUT ──
    new Chart('kraDonut', {
      type: 'doughnut',
      data: {
        labels: depts,
        datasets: [
          {
            data: data.kraDonut,
            backgroundColor: ['#22c55e','#f97316','#ef4444','#3b82f6','#f59e0b','#10b981','#8b5cf6','#ec4899'],
          },
        ],
      }
    });

    // ── GAUGE ──
    new Chart('kraGauge', {
      type: 'doughnut',
      data: {
        datasets: [
          {
            data: [82.4, 17.6],
            backgroundColor: ['#10b981', 'rgba(255,255,255,0.08)'],
            circumference: 180,
            rotation: 270,
          },
        ],
      }
    });

    // ── LINE ──
    new Chart('kraLineChart', {
      type: 'line',
      data: {
        labels: depts,
        datasets: [
          {
            label: 'KRA score',
            data: data.kraScore,
            borderColor: '#3b82f6',
            tension: 0.4,
          },
          {
            label: 'Memo volume',
            data: data.memos,
            borderColor: '#ef4444',
            tension: 0.4,
          },
        ],
      }
    });

    // ── POLICY DONUT ──
    new Chart('policyDonut', {
      type: 'doughnut',
      data: {
        labels: ['Pending', 'Non-compliant', 'Compliant', 'NA'],
        datasets: [
          {
            data: [15, 20, 55, 10],
            backgroundColor: ['#f59e0b', '#ef4444', '#22c55e', '#94a3b8'],
          },
        ],
      }
    });
  }
}